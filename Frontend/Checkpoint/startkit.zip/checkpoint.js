function round(number) {
    return +number.toFixed(10);
}

const allGnomes = [
    { file: "garden.jpg", description: "garden gnome", price: 400 },
    { file: "lady.jpg", description: "lady gnome", price: 120 },
    { file: "laugh.jpg", description: "laughing gnome", price: 300 },
    { file: "military.jpg", description: "military gnome", price: 240 },
    { file: "red-hat.jpg", description: "red hat", price: 10 },
    { file: "summer.jpg", description: "double summer", price: 80 }
]

/* write your code here... */